# asteroid-invasion
try to shoot as much asteroids as possible to beat your highscore.
controls are space to shoot and left and right arrow to move.
 if ther are any issues feel free to tell me. enjoy the game.
